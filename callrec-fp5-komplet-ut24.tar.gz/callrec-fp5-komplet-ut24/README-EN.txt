CALLRECORDER FP5 + WAV FILENAME ADD-ON — ARCHIVE BUNDLE
Fairphone 5 · Ubuntu Touch 24.04 · English installation guide
=============================================================

The bundle contains TWO INDEPENDENT COMPONENTS:
01-CallRecorder-nagrywanie/ — records calls on modem /ril_0.
02-CallRecorder-dodatek-nazwy/ — adds numbers to COMPLETED WAV filenames.

ON YOUR CURRENT PHONE: if both scripts are already working, DO NOT run
these installers again. Keep the archive as a backup for a future clean
Ubuntu Touch installation.

INSTALLING ON A CLEAN UBUNTU TOUCH 24.04 SYSTEM
----------------------------------------------
1. Install Terminal from OpenStore. Use your regular phone account,
   not sudo. Download the archive to ~/Downloads.

2. Extract:

   cd ~/Downloads
   tar -xzf callrec-fp5-komplet-ut24.tar.gz
   cd callrec-fp5-komplet-ut24

3. Install the BASE RECORDER first:

   cd 01-CallRecorder-nagrywanie
   bash ./recorder.sh --check
   bash ./install.sh
   systemctl --user is-active callrec-fp5.service

4. Make a short, consented test call and check:

   ls -lt ~/MyRec | head

   Play back the WAV and verify that BOTH sides are audible.
   Reboot and confirm recording works again BEFORE adding the renamer.

5. Install the independent FILENAME ADD-ON:

   cd ~/Downloads/callrec-fp5-komplet-ut24/02-CallRecorder-dodatek-nazwy
   bash ./instaluj.sh
   systemctl --user is-active callrec-fp5-nazwy.service

6. Make a test call. The default mode is PREVIEW (no files renamed):

   journalctl --user -u callrec-fp5-nazwy.service -n 30 --no-pager

7. After successful preview, enable AUTO mode between calls:

   bash ~/Downloads/callrec-fp5-komplet-ut24/02-CallRecorder-dodatek-nazwy/wlacz-auto.sh

   Make another test call and inspect:

   ls -lt ~/MyRec | head

MANAGEMENT AND SAFE FALLBACK
----------------------------
Disable ONLY the add-on, leaving recording untouched:

   systemctl --user disable --now callrec-fp5-nazwy.service

Return the add-on to preview:

   bash ~/Downloads/callrec-fp5-komplet-ut24/02-CallRecorder-dodatek-nazwy/wylacz-auto.sh

Uninstall ONLY the add-on:

   bash ~/Downloads/callrec-fp5-komplet-ut24/02-CallRecorder-dodatek-nazwy/odinstaluj.sh

Uninstall the recorder only if you truly need to:

   bash ~/Downloads/callrec-fp5-komplet-ut24/01-CallRecorder-nagrywanie/uninstall.sh

Neither uninstaller deletes files in ~/MyRec.

LIMITATIONS
-----------
* Both components intentionally use oFono modem /ril_0.
* A number is appended only if oFono actually supplies caller ID.
* This base recorder is an unofficial adaptation, not the original OTA-2.
* It was reported working on one FP5, but a fresh installation on
  another device still requires real-world testing.
* Call recording and storing phone numbers may have legal/privacy
  implications. Obtain consent where required and protect the data.

Add-on documentation: 02-CallRecorder-dodatek-nazwy/README-EN.txt
Polish version: README-PL.txt; additional documentation inside folders.
