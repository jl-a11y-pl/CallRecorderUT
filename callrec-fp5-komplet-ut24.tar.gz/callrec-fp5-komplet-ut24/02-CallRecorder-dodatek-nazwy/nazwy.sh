#!/usr/bin/env bash
# Independent WAV renamer for CallRecorder on Fairphone 5 / Ubuntu Touch 24.04.
# Does NOT manage callrec-fp5.service, PulseAudio, parecord, or recorder.sh.
set -u
umask 077

OUTDIR="${CALLREC_OUTDIR:-$HOME/MyRec}"
STATEDIR="${CALLREC_NAME_STATE:-$HOME/.local/state/callrec-fp5-nazwy}"
MODEFILE="$STATEDIR/mode"
MODEM='/ril_0'

log() { printf '%s %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*" >&2; }

# Read a phone number only when EXACTLY ONE call is active/held.
# Using the same field verified by the separate, manual oFono number test.
number_from_ofono() {
  local reply numbers number
  reply=$(dbus-send --system --print-reply --dest=org.ofono "$MODEM" org.ofono.VoiceCallManager.GetCalls 2>/dev/null) || return 0
  numbers=$(printf '%s\n' "$reply" | awk '
    function quoted(line, v) { v=line; sub(/^[^"]*"/, "", v); sub(/".*$/, "", v); return v }
    function emit( n) {
      if (path != "" && (state == "active" || state == "held")) {
        n = number
        gsub(/[^0-9]/, "", n)
        if (n == "") n = "?"
        printf "%s\n", n
      }
    }
    /^[[:space:]]*object path "/ { emit(); path=quoted($0); state=""; number=""; key=""; next }
    /^[[:space:]]*string "State"[[:space:]]*$/ { key="state"; next }
    /^[[:space:]]*string "LineIdentification"[[:space:]]*$/ { key="number"; next }
    /^[[:space:]]*variant[[:space:]]+string "/ {
      v=quoted($0)
      if (key == "state") state=v
      if (key == "number") number=v
      key=""
    }
    END { emit() }
  ')
  # Never guess which number belongs to the recording if multiple calls exist.
  [ "$(printf '%s\n' "$numbers" | sed '/^$/d' | wc -l)" -eq 1 ] || return 0
  number=$numbers
  [[ "$number" =~ ^[0-9]{1,32}$ ]] || return 0
  printf '%s' "$number"
}

valid_id() {
  # Exactly the final name pattern produced by the verified /ril_0 recorder.
  [[ "$1" =~ ^([0-9]{4}-[0-9]{2}-[0-9]{2}_[0-9]{2}-[0-9]{2}-[0-9]{2})_([0-9]{1,5})$ ]]
}

mode() {
  local value='preview'
  if [ -f "$MODEFILE" ]; then IFS= read -r value < "$MODEFILE" || true; fi
  if [ "$value" = 'auto' ]; then printf auto; else printf preview; fi
}

scan() {
  local f id p nfile number='' queried=0 marker src target stamp base suffix
  local -a current
  [ -d "$OUTDIR" ] || return 0
  shopt -s nullglob
  current=("$OUTDIR"/*.wav.partial)
  # State is only created for recordings observed IN PROGRESS.
  for f in "${current[@]}"; do
    [ -f "$f" ] && [ ! -L "$f" ] || continue
    id=${f##*/}; id=${id%.wav.partial}
    valid_id "$id" || continue
    marker="$STATEDIR/$id.pending"
    nfile="$STATEDIR/$id.number"
    if [ ! -e "$marker" ] && [ ! -L "$marker" ]; then
      ( set -C; : > "$marker" ) 2>/dev/null || continue
    fi
    [ -L "$marker" ] && continue
    if [ ! -s "$nfile" ] && [ ! -L "$nfile" ]; then
      if [ "$queried" -eq 0 ]; then number=$(number_from_ofono); queried=1; fi
      if [[ "$number" =~ ^[0-9]{1,32}$ ]]; then
        ( set -C; printf '%s\n' "$number" > "$nfile" ) 2>/dev/null || true
      fi
    fi
  done

  for marker in "$STATEDIR"/*.pending; do
    [ -f "$marker" ] && [ ! -L "$marker" ] || continue
    id=${marker##*/}; id=${id%.pending}
    valid_id "$id" || continue
    stamp=${BASH_REMATCH[1]}
    src="$OUTDIR/$id.wav"
    # Only finalized WAVs, never .partial or symlink sources.
    [ -f "$src" ] && [ ! -L "$src" ] || continue
    [ -e "$OUTDIR/$id.wav.partial" ] && continue
    nfile="$STATEDIR/$id.number"
    number=''
    if [ -f "$nfile" ] && [ ! -L "$nfile" ]; then
      IFS= read -r number < "$nfile" || true
    fi
    if ! [[ "$number" =~ ^[0-9]{1,32}$ ]]; then
      log "Brak pewnego numeru dla $id.wav — plik WAV pozostawiono bez zmian."
      rm -f -- "$marker" "$nfile"
      continue
    fi
    base="$OUTDIR/${stamp}_${number}"
    target="$base.wav"
    suffix=2
    while [ -e "$target" ] || [ -L "$target" ]; do
      target="${base}_${suffix}.wav"
      suffix=$((suffix+1))
    done
    if [ "$(mode)" = preview ]; then
      if [ ! -e "$STATEDIR/$id.previewed" ]; then
        log "PODGLAD: $id.wav -> ${target##*/} (plik WAV bez zmian)"
        : > "$STATEDIR/$id.previewed"
      fi
      continue
    fi
    # No overwrite: regular file moved within the same directory/filesystem.
    if mv -n -- "$src" "$target" && [ ! -e "$src" ]; then
      log "Zmieniono nazwe: $id.wav -> ${target##*/}"
      rm -f -- "$marker" "$nfile" "$STATEDIR/$id.previewed"
    else
      log "Nie zmieniono nazwy $id.wav; oryginalny WAV pozostaje."
    fi
  done
}

case "${1:-}" in
  --check)
    for cmd in dbus-send awk sed wc mv date; do command -v "$cmd" >/dev/null || { log "Brak: $cmd"; exit 1; }; done
    [ -d "$OUTDIR" ] || { log "Brak katalogu: $OUTDIR"; exit 1; }
    log 'OK: dodatek niezalezny od nagrywarki; domyslny tryb=podglad.'
    exit 0 ;;
  --once|--watch)
    mkdir -p -- "$STATEDIR" || exit 1
    chmod 700 "$STATEDIR" 2>/dev/null || true
    if [ "${1:-}" = --once ]; then scan; exit 0; fi
    log 'Dodatek uruchomiony: podglad nazw (lub auto po osobnym wlaczeniu).'
    trap 'exit 0' INT TERM
    while :; do scan; sleep 1; done ;;
  *)
    printf 'Uzycie: %s --check|--once|--watch\n' "${0##*/}" >&2
    exit 2 ;;
esac
