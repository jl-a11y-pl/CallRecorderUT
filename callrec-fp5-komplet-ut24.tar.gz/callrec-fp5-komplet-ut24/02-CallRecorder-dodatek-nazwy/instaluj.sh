#!/usr/bin/env bash
# Installs ONLY an independent filename watcher. Never edits recorder.sh.
set -euo pipefail
umask 077
[ "$(id -u)" -ne 0 ] || { echo 'Nie uzywaj sudo.' >&2; exit 1; }
SRC=$(CDPATH='' cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
BASE="$HOME/.local/share/callrec-fp5/recorder.sh"
DST="$HOME/.local/share/callrec-fp5-nazwy"
UNITDIR="$HOME/.config/systemd/user"
STATE="$HOME/.local/state/callrec-fp5-nazwy"
[ -f "$BASE" ] || { echo 'Nie ma zainstalowanego CallRecorder.' >&2; exit 1; }
[ -d "$HOME/MyRec" ] || { echo 'Brak katalogu ~/MyRec.' >&2; exit 1; }
systemctl --user is-active --quiet callrec-fp5.service || { echo 'Usługa nagrywania nie jest aktywna; przerwano.' >&2; exit 1; }
bash -n "$SRC/nazwy.sh"
bash "$SRC/nazwy.sh" --check
mkdir -p "$DST" "$UNITDIR" "$STATE"
chmod 700 "$DST" "$STATE"
# Do not disturb a service with same name installed from another package.
if [ -e "$UNITDIR/callrec-fp5-nazwy.service" ]; then
  echo 'Dodatek jest juz zainstalowany. Najpierw sprawdz jego stan.' >&2
  exit 1
fi
printf 'preview\n' > "$STATE/mode"
cp -- "$SRC/nazwy.sh" "$DST/nazwy.sh"
chmod 700 "$DST/nazwy.sh"
cp -- "$SRC/callrec-fp5-nazwy.service" "$UNITDIR/callrec-fp5-nazwy.service"
systemctl --user daemon-reload
systemctl --user enable --now callrec-fp5-nazwy.service
printf 'Zainstalowano DODATEK W TRYBIE PODGLADU. recorder.sh i usluga nagrywania nie zostaly zmienione.\n'
