#!/usr/bin/env bash
set -euo pipefail
[ "$(id -u)" -ne 0 ] || { echo 'Nie uzywaj sudo.' >&2; exit 1; }
UNIT="$HOME/.config/systemd/user/callrec-fp5-nazwy.service"
systemctl --user disable --now callrec-fp5-nazwy.service 2>/dev/null || true
rm -f -- "$UNIT"
systemctl --user daemon-reload
rm -f -- "$HOME/.local/share/callrec-fp5-nazwy/nazwy.sh"
rmdir "$HOME/.local/share/callrec-fp5-nazwy" 2>/dev/null || true
printf 'Usunieto usluge DODATKU. Nagrania, recorder.sh i callrec-fp5.service pozostaly bez zmian.\n'
printf 'Stan dodatku mozna zostawic: ~/.local/state/callrec-fp5-nazwy\n'
