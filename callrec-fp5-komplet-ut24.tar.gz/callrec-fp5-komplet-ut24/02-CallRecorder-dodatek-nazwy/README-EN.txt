CALLRECORDER FP5 — INDEPENDENT WAV FILENAME ADD-ON
Ubuntu Touch 24.04 · Fairphone 5 · English guide
=================================================

1. OVERVIEW
-----------
This add-on DOES NOT record calls. It runs separately alongside a working
CallRecorder FP5 installation and can add the call's phone number to the
FINALIZED WAV filename. The original recorder must work first.

Example original filename:
  2026-11-16_20-45-30_12345.wav
Example renamed filename:
  2026-11-16_20-45-30_48501234567.wav
The original trailing digits are a random recording ID, not a phone number.
The renamed file contains the number with non-digits removed.

How it works:
* Watches for new *.wav.partial files created by CallRecorder.
* Reads LineIdentification from oFono on modem /ril_0 during the call.
* Saves the number in the add-on's own private state directory.
* Can rename ONLY the completed *.wav after recording has finished.

It does not edit ~/.local/share/callrec-fp5/recorder.sh, control parecord,
switch PulseAudio profiles, stop/restart callrec-fp5.service, or touch
previously recorded WAV files.

2. REQUIREMENTS
---------------
* Fairphone 5 running Ubuntu Touch 24.04, with a Terminal app.
* Working CallRecorder FP5 installation configured for /ril_0.
* Active per-user service callrec-fp5.service and ~/MyRec directory.
* oFono access through the system D-Bus and standard shell utilities.
* Run as the phone user (normally phablet); DO NOT use sudo.

This archive includes ONLY the renamer. On a CLEAN Ubuntu Touch install,
first install the base CallRecorder FP5 package, verify a real recorded
call and automatic startup after reboot, then install this add-on.

3. INSTALLATION ON A PHONE WITH WORKING CALLRECORDER
---------------------------------------------------
Do not install during an ongoing phone call. Put the archive in ~/Downloads:

  cd ~/Downloads
  tar -xzf callrec-fp5-dodatek-nazwy-ut24.tar.gz
  cd callrec-fp5-dodatek-nazwy-ut24
  bash instaluj.sh

This installs a separate user service: callrec-fp5-nazwy.service.
It starts in PREVIEW mode — NO WAV filenames are changed.
If the add-on is already installed, the installer refuses to overwrite it.
Do not reinstall an add-on that already works.

Check both services:

  systemctl --user is-active callrec-fp5.service
  systemctl --user is-active callrec-fp5-nazwy.service

An active service alone does NOT prove successful recording.

4. SAFE PREVIEW TEST
--------------------
Make a short, consented test call, then run:

  journalctl --user -u callrec-fp5-nazwy.service -n 30 --no-pager
  ls -lt ~/MyRec | head

Look for "PODGLAD: original.wav -> new_PHONE.wav" in the log.
The actual WAV should still have its original filename. Check that the
base recorder still captured both call participants.

5. ENABLE AUTOMATIC RENAMING
----------------------------
Only after a successful preview test, between calls, run:

  bash ~/Downloads/callrec-fp5-dodatek-nazwy-ut24/wlacz-auto.sh

Only NEW recordings observed after enabling auto mode are renamed.
Previously recorded WAV files are not batch-renamed. The WAV contents
are preserved; only the completed file is renamed in the same folder.

Review results:

  ls -lt ~/MyRec | head
  journalctl --user -u callrec-fp5-nazwy.service -n 30 --no-pager

Return to preview mode:

  bash ~/Downloads/callrec-fp5-dodatek-nazwy-ut24/wylacz-auto.sh

6. STOP / RESUME / UNINSTALL
----------------------------
Stop ONLY this add-on (the recorder continues running):

  systemctl --user disable --now callrec-fp5-nazwy.service

Resume ONLY this add-on:

  systemctl --user enable --now callrec-fp5-nazwy.service

Uninstall ONLY this add-on (between calls):

  bash ~/Downloads/callrec-fp5-dodatek-nazwy-ut24/odinstaluj.sh

The uninstaller neither deletes WAVs nor reverts filenames already
changed. It does NOT uninstall or modify callrec-fp5.service or
recorder.sh. Its private state directory may remain at:
  ~/.local/state/callrec-fp5-nazwy

7. LIMITATIONS, PRIVACY, TROUBLESHOOTING
---------------------------------------
* When oFono does not reveal a number (hidden caller ID or an issue in
  the modem/phone stack), the original WAV filename is preserved.
* For multiple concurrent calls, the add-on will not guess the number.
* Earlier WAV recordings are not processed automatically.
* It expects the filename pattern and *.wav.partial files produced by
  the verified base recorder.
* Journal logs and renamed files may disclose phone numbers.
* Operation after reboot was reported working by the user on one FP5;
  this does not guarantee compatibility with other devices/ports/SIMs.
* If any problem occurs, stop ONLY the add-on and verify recording.
* Follow applicable call recording laws and consent requirements.

8. PACKAGE FILES
----------------
  nazwy.sh                     — monitor / rename completed WAVs
  callrec-fp5-nazwy.service    — independent per-user systemd service
  instaluj.sh                  — preview-mode installer
  wlacz-auto.sh                — enable automatic naming
  wylacz-auto.sh               — return to preview mode
  odinstaluj.sh                — remove this add-on only
  README-PL.txt / README-EN.txt — full Polish / English guides
  SZYBKI-START-PL.txt / QUICK-START-EN.txt — quick starts
  SHA256SUMS.txt               — file checksums

CODE PROVENANCE: executable files were copied WITHOUT CHANGES from the
previously delivered and user-tested 'callrec-fp5-nazwy-final' package.
Only documentation and packaging were updated. This is an experimental,
unofficial add-on; it is not an official UBports release.
