#!/usr/bin/env bash
set -euo pipefail
umask 077
[ "$(id -u)" -ne 0 ] || { echo 'Nie uzywaj sudo.' >&2; exit 1; }
STATE="$HOME/.local/state/callrec-fp5-nazwy"
[ -d "$STATE" ] || { echo 'Brak stanu dodatku.' >&2; exit 1; }
printf 'preview\n' > "$STATE/mode"
printf 'Przywrocono tryb podgladu; nagrywanie bez zmian.\n'
