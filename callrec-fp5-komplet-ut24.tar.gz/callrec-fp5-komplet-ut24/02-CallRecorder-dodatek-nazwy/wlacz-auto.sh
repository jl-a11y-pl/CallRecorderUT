#!/usr/bin/env bash
set -euo pipefail
umask 077
[ "$(id -u)" -ne 0 ] || { echo 'Nie uzywaj sudo.' >&2; exit 1; }
STATE="$HOME/.local/state/callrec-fp5-nazwy"
UNIT="$HOME/.config/systemd/user/callrec-fp5-nazwy.service"
[ -f "$UNIT" ] || { echo 'Najpierw zainstaluj dodatek.' >&2; exit 1; }
# Only enable between calls. Refuse if any recording is in progress.
shopt -s nullglob
recording=("$HOME"/MyRec/*.wav.partial)
[ "${#recording[@]}" -eq 0 ] || { echo 'Nagrywanie trwa; sprobuj po zakonczeniu rozmowy.' >&2; exit 1; }
mkdir -p "$STATE"
chmod 700 "$STATE"
# Discard only our preview records; this does NOT touch WAVs.
for f in "$STATE"/*.pending "$STATE"/*.number "$STATE"/*.previewed; do
  [ -e "$f" ] && rm -f -- "$f"
done
printf 'auto\n' > "$STATE/mode"
if ! systemctl --user is-active --quiet callrec-fp5-nazwy.service; then
  systemctl --user start callrec-fp5-nazwy.service
fi
printf 'Automatyczne nazwy wlaczone (TYLKO dla kolejnych nagran). Nagrywarka niezmieniona.\n'
