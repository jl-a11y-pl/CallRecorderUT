CALLRECORDER FP5 — DODATEK DO NAZW PLIKÓW WAV
Ubuntu Touch 24.04 · Fairphone 5 · instrukcja po polsku
===================================================

1. OPIS I PRZEZNACZENIE
----------------------
Ten dodatek NIE nagrywa rozmów. Działa obok wcześniej zainstalowanego
CallRecorder FP5 i może uzupełnić nazwę gotowego pliku WAV o numer
telefonu odczytany z oFono. Nagrywarka musi już działać poprawnie.

Przykładowa nazwa pierwotna:
  2026-11-16_20-45-30_12345.wav
Przykładowa nazwa po automatycznej zmianie:
  2026-11-16_20-45-30_48501234567.wav
W przykładzie końcowe „12345” to losowy identyfikator pierwotnego
nagrania, a „48501234567” to numer telefonu, bez znaku plus.

Dodatek:
* obserwuje pliki *.wav.partial powstające podczas nagrywania,
* podczas rozmowy odczytuje LineIdentification z oFono na /ril_0,
* zapamiętuje numer w swoim własnym katalogu stanu,
* zmienia nazwę WYŁĄCZNIE gotowego *.wav, już po zakończeniu nagrywania.

Nie zmienia: ~/.local/share/callrec-fp5/recorder.sh, ustawień parecord,
profilu PulseAudio, ani usługi callrec-fp5.service. Nie zatrzymuje i nie
restartuje nagrywarki. Nie zmienia istniejących wcześniej nagrań.

2. WYMAGANIA
-----------
* Fairphone 5 z Ubuntu Touch 24.04 i terminalem.
* Zainstalowany, sprawdzony CallRecorder FP5 działający na /ril_0.
* Aktywna usługa użytkownika callrec-fp5.service.
* Katalog ~/MyRec i dostęp do oFono (org.ofono) przez systemowy D-Bus.
* Standardowe polecenia: bash, dbus-send, awk, sed, wc, mv, systemctl.
* Użytkownik telefonu (zwykle phablet), NIE root, NIE sudo.

Paczka zawiera TYLKO dodatek do nazw. W celu instalacji na całkiem
czystym systemie najpierw zainstaluj podstawowy CallRecorder FP5
z osobnej paczki, przetestuj rozmowę i dopiero potem ten dodatek.

3. INSTALACJA NA TELEFONIE Z DZIAŁAJĄCĄ NAGRYWARKĄ
-------------------------------------------------
Nie wykonuj instalacji w trakcie połączenia. Pobierz archiwum
callrec-fp5-dodatek-nazwy-ut24.tar.gz do ~/Downloads i wpisz:

  cd ~/Downloads
  tar -xzf callrec-fp5-dodatek-nazwy-ut24.tar.gz
  cd callrec-fp5-dodatek-nazwy-ut24
  bash instaluj.sh

Instalator uruchamia osobną usługę callrec-fp5-nazwy.service.
Domyślny tryb to PODGLĄD (preview): nie zmienia nazw WAV.
Jeśli dodatek jest już zainstalowany, instalator odmówi ponownego
nadpisania. Nie ma potrzeby reinstalować działającej wersji.

Sprawdzenie obu usług:

  systemctl --user is-active callrec-fp5.service
  systemctl --user is-active callrec-fp5-nazwy.service

Wynik „active” oznacza działającą usługę, NIE gwarancję nagrania.

4. BEZPIECZNY TEST W TRYBIE PODGLĄDU
-----------------------------------
Wykonaj krótką rozmowę za zgodą rozmówcy. Po rozłączeniu wpisz:

  journalctl --user -u callrec-fp5-nazwy.service -n 30 --no-pager
  ls -lt ~/MyRec | head

W dzienniku szukaj komunikatu „PODGLAD: ...wav -> ...NUMER.wav”.
Prawdziwy plik WAV nadal powinien mieć starą nazwę. Sprawdź też,
czy CallRecorder nagrał obie strony rozmowy.

5. WŁĄCZENIE AUTOMATYCZNEJ ZMIANY NAZW
-------------------------------------
Dopiero po poprawnym teście PODGLĄDU, poza rozmową, wpisz:

  bash ~/Downloads/callrec-fp5-dodatek-nazwy-ut24/wlacz-auto.sh

Zmiana dotyczy tylko NOWYCH, zaobserwowanych nagrań; wcześniejszych
WAV dodatek nie przetwarza. Program nie usuwa zawartości nagrania:
przemianowuje gotowy plik w tym samym katalogu.

Sprawdzanie wyniku:

  ls -lt ~/MyRec | head
  journalctl --user -u callrec-fp5-nazwy.service -n 30 --no-pager

Powrót do podglądu:

  bash ~/Downloads/callrec-fp5-dodatek-nazwy-ut24/wylacz-auto.sh

6. ZATRZYMANIE, WZNOWIENIE, ODINSTALOWANIE
-----------------------------------------
Zatrzymaj TYLKO dodatek (nagrywarka działa dalej):

  systemctl --user disable --now callrec-fp5-nazwy.service

Włącz ponownie TYLKO dodatek:

  systemctl --user enable --now callrec-fp5-nazwy.service

Odinstaluj TYLKO dodatek (po zakończeniu rozmowy):

  bash ~/Downloads/callrec-fp5-dodatek-nazwy-ut24/odinstaluj.sh

Odinstalowanie nie przywraca wcześniejszych nazw już przemianowanych
plików i nie usuwa WAV. Nie ingeruje w callrec-fp5.service ani
recorder.sh. Własny katalog stanu dodatku może pozostać na dysku:
  ~/.local/state/callrec-fp5-nazwy

7. OGRANICZENIA I DIAGNOSTYKA
----------------------------
* Jeżeli oFono nie udostępnia numeru (np. ukryty numer lub błąd
  identyfikacji), plik zachowuje oryginalną nazwę.
* Dla kilku równoczesnych połączeń dodatek nie zgaduje numeru.
* Zapisane wcześniej WAV nie są przetwarzane automatycznie.
* Dodatek reaguje tylko na wzorzec nazwy oraz pliki *.wav.partial
  generowane przez sprawdzoną nagrywarkę.
* Dziennik zawiera numery telefonów: udostępniaj go ostrożnie.
* Poprawne działanie usług po restarcie zostało potwierdzone przez
  użytkownika na jednym Fairphone 5. Inne wersje systemu, modemy i
  konfiguracje SIM mogą zachowywać się inaczej.
* W razie problemu wyłącz tylko dodatek i sprawdź nagrywanie.
* Przestrzegaj zasad prawnych dotyczących nagrywania rozmów.

8. ZAWARTOŚĆ PACZKI
------------------
  nazwy.sh                     — monitorowanie i końcowa zmiana nazw
  callrec-fp5-nazwy.service    — odrębna usługa systemd użytkownika
  instaluj.sh                  — instalacja w trybie podglądu
  wlacz-auto.sh                — aktywacja automatycznego nazywania
  wylacz-auto.sh               — powrót do podglądu
  odinstaluj.sh                — usunięcie tylko dodatku
  README-PL.txt                — ten dokument
  README-EN.txt                — angielska instrukcja
  SZYBKI-START-PL.txt           — skrócona instrukcja
  QUICK-START-EN.txt           — skrócona instrukcja angielska
  SHA256SUMS.txt               — sumy kontrolne plików

STATUS: pliki wykonywalne tej paczki są niezmienioną kopią wcześniejszej
wersji „callrec-fp5-nazwy-final”, którą użytkownik uruchomił pomyślnie.
Dokumentacja i opakowanie zostały uzupełnione. Nie jest to oficjalny
pakiet UBports ani gwarancja zgodności ze wszystkimi telefonami.
