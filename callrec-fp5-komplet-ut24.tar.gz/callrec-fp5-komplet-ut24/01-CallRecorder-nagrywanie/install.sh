#!/usr/bin/env bash
# Instalator sprawdzonego wariantu CallRecorder FP5 Ubuntu Touch 24.04 (/ril_0).
# Nie używa sudo, apt, remount ani partycji systemowej.
set -euo pipefail
umask 077

if [ "$(id -u)" -eq 0 ]; then
  echo 'BLAD: uruchom bez sudo, z konta phablet.' >&2
  exit 1
fi

SRC=$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
for cmd in bash dbus-send pactl parecord systemctl awk grep sed date mkdir cp chmod; do
  if ! command -v "$cmd" >/dev/null 2>&1; then
    echo "BLAD: brak programu $cmd. Instalacja przerwana." >&2
    exit 1
  fi
done

bash -n "$SRC/recorder.sh"
echo 'Sprawdzam oFono i wymagane polecenia...'
bash "$SRC/recorder.sh" --check || {
  echo 'Test nie przeszedl. Niczego nie instalowano.' >&2
  exit 1
}

DST="$HOME/.local/share/callrec-fp5"
UNITDIR="$HOME/.config/systemd/user"
UNIT="$UNITDIR/callrec-fp5.service"
OUTDIR="$HOME/MyRec"

# Jeśli istniała wcześniejsza instalacja, nie nadpisujemy jej bez kopii.
if [ -f "$DST/recorder.sh" ] || [ -f "$UNIT" ]; then
  BACKUP="$HOME/Downloads/callrec-fp5-kopia-$(date +%Y%m%d-%H%M%S)-$$"
  mkdir -p "$BACKUP"
  [ ! -f "$DST/recorder.sh" ] || cp -p "$DST/recorder.sh" "$BACKUP/recorder.sh"
  [ ! -f "$UNIT" ] || cp -p "$UNIT" "$BACKUP/callrec-fp5.service"
  echo "Kopia poprzedniej instalacji: $BACKUP"
fi

# Zatrzymujemy ewentualną starszą instancję.
systemctl --user stop callrec-fp5.service 2>/dev/null || true
mkdir -p "$DST" "$UNITDIR" "$OUTDIR"
chmod 700 "$OUTDIR"
cp "$SRC/recorder.sh" "$DST/recorder.sh"
chmod 700 "$DST/recorder.sh"
cp "$SRC/callrec-fp5.service" "$UNIT"
chmod 600 "$UNIT"

systemctl --user daemon-reload
if ! systemctl --user enable --now callrec-fp5.service; then
  echo 'BLAD: nie udalo sie wlaczyc uslugi. Sprawdz:' >&2
  echo 'journalctl --user -u callrec-fp5.service -n 50 --no-pager' >&2
  echo 'Jesli istniala poprzednia instalacja, jej kopia jest w Downloads.' >&2
  exit 1
fi

echo
echo 'CallRecorder zainstalowany.'
echo 'Nagrania: ~/MyRec'
echo 'Status: systemctl --user is-active callrec-fp5.service'
echo 'Dziennik: journalctl --user -u callrec-fp5.service -n 40 --no-pager'
echo 'Przetestuj rozmowe i sprawdz, czy nagrywaja sie obie strony.'
