#!/usr/bin/env bash
# CallRecorder FP5 / Noble - eksperymentalna wersja korzystająca z PulseAudio
set -u
umask 077

CARD=droid_card.primary
SOURCE=source.primary_input
OUTDIR="$HOME/MyRec"
mkdir -p "$OUTDIR" || exit 1
chmod 700 "$OUTDIR" 2>/dev/null || true

modem=''
rec_pid=''
partial=''
final=''

log() { printf '%s %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*" >&2; }
profile() { LC_ALL=C pactl list cards 2>/dev/null | sed -n 's/^[[:space:]]*Active Profile: //p' | head -n 1; }
get_modem() {
  local out
  out=$(dbus-send --system --print-reply --dest=org.ofono / org.ofono.Manager.GetModems 2>/dev/null) || return 1
  modem=/ril_0
  [ -n "$modem" ]
}
# 0: trwa odebrana rozmowa; 1: brak aktywnej rozmowy; 2: D-Bus nie działa
call_state() {
  local out
  [ -n "$modem" ] || get_modem || return 2
  if ! out=$(dbus-send --system --print-reply --dest=org.ofono "$modem" org.ofono.VoiceCallManager.GetCalls 2>/dev/null); then
     modem=''
     return 2
  fi
  if printf '%s\n' "$out" | grep -qE 'string "(active|held)"'; then
     return 0
  fi
  return 1
}
restore_profile() {
  local current state
  current=$(profile)
  [ "$current" = 'voicecall-record' ] || return 0
  # Nie zmieniaj trybu rozmowy na domyślny, gdy połączenie trwa.
  call_state; call_rc=$?
  # Przy niepewnym stanie (błąd oFono) nie przełączaj telefonu w default.
  if [ "$call_rc" -eq 1 ]; then state=default; else state=voicecall; fi
  pactl set-card-profile "$CARD" "$state" >/dev/null 2>&1 || log 'Nie udało się przywrócić profilu audio.'
}
stop_rec() {
  if [ -n "$rec_pid" ]; then
    kill -TERM "$rec_pid" 2>/dev/null || true
    for _ in 1 2 3 4 5 6 7 8 9 10; do
      if ! kill -0 "$rec_pid" 2>/dev/null; then break; fi
      sleep 0.2
    done
    if kill -0 "$rec_pid" 2>/dev/null; then kill -KILL "$rec_pid" 2>/dev/null || true; fi
    wait "$rec_pid" 2>/dev/null || true
    rec_pid=''
  fi
  if [ -n "$partial" ] && [ -s "$partial" ]; then
    mv -n -- "$partial" "$final" && log "Zapisano nagranie: $final"
  elif [ -n "$partial" ]; then
    rm -f -- "$partial"
  fi
  partial=''
  final=''
  restore_profile
}
cleanup() { stop_rec; }
trap 'exit 0' INT TERM
trap cleanup EXIT

if [ "${1:-}" = '--check' ]; then
  for c in dbus-send pactl parecord; do
     command -v "$c" >/dev/null 2>&1 || { log "Brak programu: $c"; exit 1; }
  done
  get_modem || { log 'Brak dostępu do oFono z konta użytkownika.'; exit 1; }
  call_state; st=$?
  if [ "$st" -eq 2 ]; then log 'Brak dostępu do oFono VoiceCallManager.GetCalls.'; exit 1; fi
  log "OK: oFono odpowiada; modem=$modem; bieżący profil=$(profile)"
  exit 0
fi

log 'Uruchomiono nasłuchiwanie połączeń.'
# Zanim włączymy nagrywanie, sprawdzamy w oFono stan active.
while :; do
  if call_state; then active=0; else active=$?; fi
  if [ "$active" -eq 0 ]; then
    if [ -z "$rec_pid" ]; then
      current=$(profile)
      if [ "$current" = 'voicecall' ]; then
        if pactl set-card-profile "$CARD" voicecall-record >/dev/null 2>&1; then
          # Format potwierdzony podczas testu użytkownika.
          final="$OUTDIR/$(date +%Y-%m-%d_%H-%M-%S)_$RANDOM.wav"
          partial="$final.partial"
          parecord -d "$SOURCE" --file-format=wav --rate=16000 --channels=1 "$partial" &
          rec_pid=$!
          sleep 0.4
          if ! kill -0 "$rec_pid" 2>/dev/null; then
            log 'parecord zakończył się bez rozpoczęcia nagrywania.'
            stop_rec
          else
            log 'Rozpoczęto nagrywanie aktywnej rozmowy.'
          fi
        else
          log 'Nie udało się aktywować profilu voicecall-record.'
        fi
      fi
    elif ! kill -0 "$rec_pid" 2>/dev/null; then
      log 'Proces parecord zakończył się nieoczekiwanie.'
      stop_rec
    fi
  else
    if [ -n "$rec_pid" ]; then
      log 'Rozmowa zakończona lub utracono kontakt z oFono; kończę nagrywanie.'
      stop_rec
    fi
  fi
  # Mniejsza częstotliwość sprawdzania, kiedy rozmowa nie trwa.
  if [ "$active" -eq 0 ]; then sleep 1; else sleep 3; fi
done
