#!/usr/bin/env bash
# Odinstalowanie CallRecorder bez kasowania nagran.
set -euo pipefail
if [ "$(id -u)" -eq 0 ]; then
  echo 'Uruchom bez sudo.' >&2
  exit 1
fi
systemctl --user disable --now callrec-fp5.service 2>/dev/null || true
rm -f -- "$HOME/.config/systemd/user/callrec-fp5.service"
systemctl --user daemon-reload
rm -f -- "$HOME/.local/share/callrec-fp5/recorder.sh"
rmdir "$HOME/.local/share/callrec-fp5" 2>/dev/null || true
echo 'CallRecorder odinstalowany. Wszystkie nagrania w ~/MyRec zachowano.'
