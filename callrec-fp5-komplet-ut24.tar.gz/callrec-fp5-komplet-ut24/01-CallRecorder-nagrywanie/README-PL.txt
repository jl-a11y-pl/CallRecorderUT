CALLRECORDER FP5 — INSTALACJA NA CZYSTYM UBUNTU TOUCH 24.04
===========================================================
Wariant: /ril_0, 16 kHz mono, profil voicecall-record
Data przygotowania: 16.11.2026
Status: wersja eksperymentalna, sprawdzona w rozmowie na jednym Fairphone 5.

1. CO TO JEST?
----------------
CallRecorder FP5 jest prostym skryptem Bash, który automatycznie wykrywa
odebrane rozmowy komórkowe za pomocą oFono, przełącza profil dźwięku
PulseAudio na voicecall-record, nagrywa przez parecord i zapisuje WAV.
Gdy rozmowa się kończy, zatrzymuje nagrywanie oraz przywraca profil audio.
Działa jako usługa systemd użytkownika (bez sudo).

Ta paczka NIE jest oryginalnym callrecorder-ota.2. Jest niezależną,
eksperymentalną adaptacją przygotowaną na podstawie testów użytkownika
Fairphone 5 z Ubuntu Touch 24.04. Oryginalne archiwum nie jest wymagane.

WAŻNE: Jest to WERSJA, KTÓRA NAGRYWAŁA rozmowy po ustawieniu /ril_0.
Nie ma jeszcze dodawania numeru telefonu do nazwy pliku — poprzednia
próba takiej modyfikacji zakłócała automatyczne nagrywanie.

2. ZAWARTOŚĆ PACZKI
-------------------
recorder.sh          — główny skrypt wykrywający i nagrywający rozmowy.
callrec-fp5.service  — definicja usługi systemd użytkownika.
install.sh           — instalator (bez sudo; kopia istniejącej wersji).
uninstall.sh         — deinstalator (nie usuwa nagrań).
README-PL.txt        — ten opis i pełna instrukcja.
INSTRUKCJA-SZYBKA.txt — skrócona instrukcja do Terminala.

3. WYMAGANIA I ZGODNOŚĆ
------------------------
• Fairphone 5, Ubuntu Touch 24.04 (test wykonany na urządzeniu użytkownika).
• Dostęp do oFono na magistrali systemowej: org.ofono.
• Programy: bash, dbus-send, pactl, parecord, systemctl i podstawowe narzędzia.
• Profil PulseAudio: voicecall podczas rozmowy, voicecall-record do nagrania.
• Źródło: source.primary_input; karta: droid_card.primary.
• Aktywny modem /ril_0. To ważne: w telefonie z testów automatyczny
  wybór pierwszego modemu wskazywał /ril_1 i nie nagrywał rozmów.

Na innym egzemplarzu FP5, innej konfiguracji SIM lub innej wersji portu
nazwy urządzeń i dostępność przechwytywania rozmów mogą się różnić.
Nie można obiecać poprawnego działania na każdym urządzeniu.

4. CZYSTA INSTALACJA — KROK PO KROKU
------------------------------------
A. Zainstaluj aplikację Terminal z OpenStore, jeśli jej nie masz.
B. Pobierz plik callrec-fp5-ut24-sprawdzony-ril0.tar.gz na telefon.
C. Umieść go w katalogu Downloads. W Terminalu wykonaj:

   cd ~/Downloads
   tar -xzf callrec-fp5-ut24-sprawdzony-ril0.tar.gz
   cd callrec-fp5-ut24-sprawdzony-ril0

D. Sprawdź zależności i dostępność oFono:

   bash ./recorder.sh --check

   Oczekiwany jest komunikat „OK: oFono odpowiada; modem=/ril_0”.
   Poza rozmową profil dźwięku zwykle ma wartość default.
   Jeśli wystąpi błąd — NIE uruchamiaj instalatora.

E. Zainstaluj i włącz automatyczny start:

   bash ./install.sh

   Nie używaj sudo. Instalator korzysta z katalogu użytkownika.
   Jeśli była wcześniejsza instalacja, jej kopia trafi do Downloads.

F. Sprawdź stan:

   systemctl --user is-active callrec-fp5.service
   systemctl --user is-enabled callrec-fp5.service

   Prawidłowe odpowiedzi to zwykle: active oraz enabled.
   UWAGA: active oznacza tylko, że usługa działa, a nie że nagrywa rozmowy.

G. Wykonaj za zgodą rozmówcy krótką rozmowę testową (15–30 sekund).
   Po rozłączeniu wpisz:

   ls -lt ~/MyRec | head

   Otwórz nowy WAV i SPRAWDŹ, czy słychać obie strony rozmowy.
   Następnie uruchom telefon ponownie i powtórz test.

5. JAK DZIAŁA NAGRYWANIE
------------------------
• Skrypt pyta oFono co kilka sekund o stan połączenia na /ril_0.
• Rozpoczyna nagrywanie odebranej rozmowy w stanie active lub held, gdy
  aktywny profil audio to voicecall.
• Zmienia profil na voicecall-record i uruchamia parecord.
• Parametry parecord: 16 000 Hz, 1 kanał (mono), kontener WAV.
• Najpierw tworzy plik tymczasowy .wav.partial, a po zakończeniu
  zmienia jego nazwę na .wav.
• Nie nagrywa rozmów nieodebranych.
• Może pominąć pierwsze sekundy rozmowy, zanim wykryje jej stan.
• Nagrania są lokalne; program sam ich nie wysyła ani nie usuwa.

6. NAZWY I LOKALIZACJA NAGRAŃ
-----------------------------
Folder nagrań: /home/phablet/MyRec (czyli ~/MyRec).
Przykładowa nazwa: 2026-11-16_20-45-30_12345.wav
Znaczenie: data_godzina_liczba-losowa.wav

UWAGA: aktualna sprawdzona wersja NIE wpisuje numeru telefonu do nazwy.
Dołożenie takiej funkcji wymaga osobnej, przetestowanej aktualizacji.

Katalog MyRec otrzymuje uprawnienia 700; skrypt używa umask 077,
więc nowe nagrania są domyślnie dostępne tylko dla użytkownika.
Pliki WAV mogą zajmować dużo miejsca — kontroluj wolne miejsce w telefonie.

7. ZARZĄDZANIE USŁUGĄ
----------------------
Stan:
   systemctl --user status callrec-fp5.service

Zatrzymanie do czasu kolejnego uruchomienia usługi:
   systemctl --user stop callrec-fp5.service

Ponowne uruchomienie:
   systemctl --user start callrec-fp5.service

Wyłączenie autostartu i zatrzymanie:
   systemctl --user disable --now callrec-fp5.service

Ponowne włączenie autostartu i uruchomienie:
   systemctl --user enable --now callrec-fp5.service

Dziennik:
   journalctl --user -u callrec-fp5.service -n 50 --no-pager

Test oFono i zależności bez nagrywania:
   bash ~/.local/share/callrec-fp5/recorder.sh --check

Nie uruchamiaj dwóch instancji recorder.sh jednocześnie.

8. ODINSTALOWANIE
-----------------
Nie odinstalowuj w czasie rozmowy. W katalogu rozpakowanej paczki:

   bash ./uninstall.sh

To usuwa usługę i skrypt, ale ZACHOWUJE folder ~/MyRec i nagrania.

9. ROZWIĄZYWANIE PROBLEMÓW
---------------------------
A. active, ale nie powstaje WAV:
   - Potwierdź, że korzystasz z modemu /ril_0.
   - Sprawdź oFono: bash ~/.local/share/callrec-fp5/recorder.sh --check
   - Sprawdź ostatnie komunikaty:
     journalctl --user -u callrec-fp5.service -n 80 --no-pager
   - Sprawdź, czy w ~/MyRec nie pozostał plik .wav.partial.
   - Nie zmieniaj od razu parametrów audio: na testowanym FP5 problemem
     był niewłaściwy modem /ril_1 zamiast /ril_0.

B. Nie działa dźwięk rozmowy po awarii:
   - Zakończ połączenie; sprawdź profil:
     LC_ALL=C pactl list cards | grep 'Active Profile:'
   - Normalnie po rozmowie powinno być: default.
   - W razie problemów zatrzymaj usługę i uruchom telefon ponownie.

C. Brakuje programu pactl/parecord/dbus-send:
   - Instalacja zostanie przerwana.
   - Nie próbuj odblokowywać partycji systemowej ani instalować pakietów
     z apt bez oceny zgodności z Ubuntu Touch.

D. Połączenie przez drugą kartę SIM (/ril_1):
   - Ten pakiet jest celowo ustawiony na /ril_0, bo tak działał na
     testowanym Fairphone 5. Połączenia przez inny modem mogą być pominięte.
   - Wymagana byłaby świadoma modyfikacja detekcji i osobny test.

E. Samo is-active=active nie dowodzi prawidłowego nagrywania; wymagany jest
   odsłuch nowego WAV po prawdziwym połączeniu.

10. BEZPIECZEŃSTWO I PRYWATNOŚĆ
--------------------------------
• Nagrywanie może podlegać przepisom i obowiązkom informowania o nim;
  uzyskaj zgodę rozmówcy i przestrzegaj obowiązujących zasad.
• Skrypt ma dostęp do informacji o aktywnych połączeniach i do mikrofonu.
• Pliki przechowuj bezpiecznie; zabezpiecz telefon i wykonuj kopie zapasowe.
• Zmiana profilu voicecall-record może zakłócić dźwięk rozmowy na innych
  wersjach systemu. Przetestuj przed poleganiem na nagraniu.
• To rozwiązanie społecznościowe, bez gwarancji działania na innych
  wersjach Ubuntu Touch i bez oficjalnego wsparcia UBports.

11. PLIKI INSTALOWANE W SYSTEMIE UŻYTKOWNIKA
---------------------------------------------
~/MyRec/
~/.local/share/callrec-fp5/recorder.sh
~/.config/systemd/user/callrec-fp5.service

NIE modyfikuje /usr, /etc ani partycji systemowej; NIE wymaga sudo.

12. INFORMACJE TECHNICZNE
--------------------------
Wariant powstał przez zachowanie kodu wcześniejszej wersji programu i
zamianę jednej linii wyboru modemu na `modem=/ril_0`. Ta zmiana została
potwierdzona testem użytkownika: automatyczne nagrywanie obu stron działa
oraz połączenia są zapisywane jako WAV. Test na czystej instalacji 24.04
na innym telefonie nie został wykonany; działanie po instalacji należy
sprawdzić zgodnie z punktem 4G.

Opis obsługi profili audio:
https://github.com/FuriLabs/pulseaudio-modules-droid-modern
Opis dźwięku Ubuntu Touch:
https://docs.ubports.com/gl/latest/porting/configure_test_fix/Sound.html
Dokumentacja systemd user services:
https://www.freedesktop.org/software/systemd/man/latest/systemd.special.html
