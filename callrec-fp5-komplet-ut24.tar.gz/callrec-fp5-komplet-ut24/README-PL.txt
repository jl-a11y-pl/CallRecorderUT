CALLRECORDER FP5 + DODATEK DO NAZW — ZESTAW ARCHIWALNY
Fairphone 5 · Ubuntu Touch 24.04 · polska instrukcja
===================================================

Ten zestaw zawiera DWA NIEZALEŻNE składniki:
01-CallRecorder-nagrywanie/ — nagrywanie rozmów, modem /ril_0.
02-CallRecorder-dodatek-nazwy/ — numery telefonu w nazwach GOTOWYCH WAV.

WAŻNE DLA OBECNEGO TELEFONU: jeżeli oba skrypty już działają,
NIE URUCHAMIAJ ponownie instalatorów. Zachowaj paczkę jako kopię
bezpieczeństwa do przyszłej reinstalacji Ubuntu Touch.

INSTALACJA NA CZYSTYM UBUNTU TOUCH 24.04
---------------------------------------
1. Zainstaluj Terminal z OpenStore. Otwórz go jako zwykły użytkownik,
   nie używaj sudo. Pobierz to archiwum do ~/Downloads.

2. Rozpakuj:

   cd ~/Downloads
   tar -xzf callrec-fp5-komplet-ut24.tar.gz
   cd callrec-fp5-komplet-ut24

3. Najpierw zainstaluj NAGRYWARKĘ:

   cd 01-CallRecorder-nagrywanie
   bash ./recorder.sh --check
   bash ./install.sh
   systemctl --user is-active callrec-fp5.service

4. Wykonaj krótką rozmowę za zgodą rozmówcy. Sprawdź:

   ls -lt ~/MyRec | head

   Odsłuchaj WAV — powinny być słyszalne obie strony. Sprawdź
   także działanie po restarcie telefonu. Bez tego nie instaluj dodatku.

5. Dopiero potem zainstaluj DODATEK DO NAZW:

   cd ~/Downloads/callrec-fp5-komplet-ut24/02-CallRecorder-dodatek-nazwy
   bash ./instaluj.sh
   systemctl --user is-active callrec-fp5-nazwy.service

6. Wykonaj rozmowę testową; odczytaj sugerowaną nazwę (PODGLĄD):

   journalctl --user -u callrec-fp5-nazwy.service -n 30 --no-pager

   W PODGLĄDZIE nie są zmieniane żadne nazwy plików WAV.

7. Jeżeli podgląd jest poprawny, poza rozmową włącz automatyczne nazwy:

   bash ~/Downloads/callrec-fp5-komplet-ut24/02-CallRecorder-dodatek-nazwy/wlacz-auto.sh

   Po następnym połączeniu sprawdź:

   ls -lt ~/MyRec | head

ZARZĄDZANIE I AWARYJNE WYŁĄCZENIE DODATKU
---------------------------------------
Zatrzymaj WYŁĄCZNIE dodatek (nagrywarka działa dalej):

   systemctl --user disable --now callrec-fp5-nazwy.service

Powrót do podglądu:

   bash ~/Downloads/callrec-fp5-komplet-ut24/02-CallRecorder-dodatek-nazwy/wylacz-auto.sh

Odinstaluj WYŁĄCZNIE dodatek:

   bash ~/Downloads/callrec-fp5-komplet-ut24/02-CallRecorder-dodatek-nazwy/odinstaluj.sh

Odinstaluj nagrywarkę tylko jeśli naprawdę chcesz:

   bash ~/Downloads/callrec-fp5-komplet-ut24/01-CallRecorder-nagrywanie/uninstall.sh

Nagrania w ~/MyRec nie są usuwane przez żaden z tych instalatorów.

OGRANICZENIA
-----------
* Wariant nagrywarki i dodatku używa modemu /ril_0. Inne konfiguracje
  kart SIM lub modemów mogą wymagać dostosowania.
* Numer w nazwie pojawi się tylko, jeżeli oFono go udostępnia.
* Podstawowa nagrywarka nie jest oficjalną wersją CallRecorder OTA-2.
* Oba elementy przetestowano na jednym Fairphone 5. Test na innym
  telefonie i na świeżym obrazie systemu nadal jest zalecany.
* Zapis rozmów może podlegać wymogom prawnym. Zabezpieczaj nagrania
  i numery telefonów przed nieuprawnionym dostępem.

Szczegółowy opis dodatku: 02-CallRecorder-dodatek-nazwy/README-PL.txt
Dodatkowa dokumentacja: README-EN.txt oraz READMEs wewnątrz katalogów.
